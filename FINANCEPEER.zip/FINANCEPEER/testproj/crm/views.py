# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import json

from django.shortcuts import render, redirect

from django.views.generic import (View, ListView, TemplateView, CreateView)
from django.core.urlresolvers import reverse
from django.contrib import auth, messages



from .forms import SignupForm, UserInfoForm
from .models import *

# Create your views here.


class SignupView(CreateView):
    template_name = 'crm/signup.html'
    form_class = SignupForm
    context_object_name = "signup"
    model = User

    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.username = form.cleaned_data['email']
        
        try:
            self.object.set_password(form.cleaned_data['password1'])
            self.object.save()
        except:
            messages.error(
                self.request, 'Failed to Create user.')
        
        return redirect(self.get_success_url())

    def get_success_url(self):
        return reverse('signup_success')


class LoginSuccessView(TemplateView):
    template_name="crm/thankyou.html"

    def get_context_data(self, *args, **kwargs):
        context = super(LoginSuccessView, self).get_context_data(*args, **kwargs)
        context['user'] = self.request.user
        return context

def logout_view(request):
    request.session.flush()
    auth.logout(request)
    return redirect('login')


class UserInfoListView(ListView):
    model = UserInfo
    context_object_name = "user_info"
    template_name = 'crm/user_data_view.html'
    
    def get_queryset(self):
        user = self.request.user
        #if user wants to see his own data 
        # qs = self.model.objects.filter(user=user)
        qs = self.model.objects.all()
        return qs

 

class UploadUserData(View):
    
    field_map = {
        'userId': 'user',
        'title': 'title',
        'body': 'body',
    }
    
    def get(self, request):
        return render(request, 'crm/fileupload_view.html')
    

    def post(self, request):
        errors = []
        count = 0


        def get_values_remapped(row):
            return {self.field_map[key]: row[key] for key in self.field_map}

        file = request.FILES.get('user_info_file', '')
        if not file or not file.name.endswith('.json'):
            messages.error(request, "Please select the file and file type should be JSON")
            return redirect('upload_user_info')

        for row in json.load(file):
            try:
                remapped_row = get_values_remapped(row)
            except BaseException as e:
                ({'non_field_errors': ['Invalid data']})
            else:
                info_form = UserInfoForm(remapped_row)

                if not info_form.is_valid():
                    form_errors = {
                        'non_field_errors': info_form.non_field_errors(),
                        'field_errors': {
                            info_form.fields[name].label: info_form.errors[name]
                            for name in info_form.errors.as_data()
                            if name != '__all__'
                        }
                    }
                    errors.append(form_errors)

                else:
                    try:
                        item = info_form.save()
                        count = count + 1

                    except BaseException as e:
                        messages.error(request, 'Failed to save data.')
                        raise IntegrityError('Invalid data.')
        return render(request, 'crm/fileupload_view.html', {'errors': errors, 'count':count})






