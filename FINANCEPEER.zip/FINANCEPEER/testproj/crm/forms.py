
from django import forms
from .models import User, UserInfo





class SignupForm(forms.ModelForm):
    password1 = forms.CharField(min_length=6, max_length=100, label='Password', widget=forms.PasswordInput(attrs={'class':'input-xlarge', 'required':'required'}))
    password2 = forms.CharField(min_length=6, max_length=100, label='Confirm password', widget=forms.PasswordInput(attrs={'class':'input-xlarge', 'required':'required'}))
    def __init__(self, *args, **kwargs):
       
        super(SignupForm, self).__init__(*args, **kwargs)

    def clean(self):
        if self.cleaned_data.get('password1') != self.cleaned_data.get('password2'):
            raise forms.ValidationError('The passwords must match.')
        return self.cleaned_data

    def clean_email(self):
        email = self.cleaned_data.get('email')
        try:
            client = User.objects.get(email=email)
        except User.DoesNotExist:
            pass
        else:
            raise forms.ValidationError('That email has already been used to create a User.')
        return email

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'home_address']


class UserInfoForm(forms.ModelForm):
    class Meta:
        model = UserInfo
        fields = '__all__'