
from django.conf.urls import url
from django.views.generic import TemplateView
from django.contrib.auth.decorators import login_required


from crm.views import *



urlpatterns = [
    url(r'^signup/$', SignupView.as_view(), name='signup'),
    url(r'^$', "django.contrib.auth.views.login", {"template_name": "crm/login.html"}, name="login"),
    url(r"^signup/success/$", TemplateView.as_view(template_name="crm/thankyou.html"), name='signup_success'),
    url(r'^logout/$', logout_view, name="logout"),
    url(r'^login/success/$', login_required(LoginSuccessView.as_view()), name='login_success'),
    url(r'^user/info/list/$', login_required(UserInfoListView.as_view()), name="user_info"),
    url(r'^upload/user/info/$', login_required(UploadUserData.as_view()), name="upload_user_info"),



]

