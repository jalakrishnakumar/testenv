# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

# Create your models here.

#Custom user model


class ClientUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        # Creates and saves a User with the given email and password.
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user


class User(AbstractBaseUser):
    email = models.EmailField(unique=True, db_index=True)
    first_name = models.CharField(max_length=60, blank=True, null=True)
    last_name = models.CharField(max_length=60, blank=True, null=True)

    home_address = models.TextField(blank=True, null=True)
    objects = ClientUserManager()
    USERNAME_FIELD = 'email'


class UserInfo(models.Model):
    user = models.ForeignKey(User)
    title = models.CharField(max_length=500, null=True, blank=True)
    body = models.TextField(blank=True, null=True)


